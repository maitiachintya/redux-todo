import React from 'react'

const PageNotFound = () => {
    return (
        <div>
            <h2>404! Sorry Page Not Found here...</h2>
        </div>
    )
}

export default PageNotFound
